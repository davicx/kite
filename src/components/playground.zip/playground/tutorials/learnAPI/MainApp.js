import React, { useState } from 'react'
import Activities from './components/Activities';
import MyAPI from './components/MyAPI'; 
const MainApp = () => {

  return (
      <div> 
        <MyAPI />
      </div>
  );
}


export default MainApp;



